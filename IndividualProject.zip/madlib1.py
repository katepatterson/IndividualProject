class Madlib1:
  print("Please enter the following words to create your own story.")
  adjective = input("Enter an adjective: ")
  animal = input("Enter an animal: ")
  noun = input("Enter a noun: ")

  story1 = ("Once upon a time, there was a" + " "+ adjective + " " + animal + " " "who lived in a" + " " + noun)
  print(story1)