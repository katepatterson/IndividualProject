class Madlib3:
  print("Please enter the following words to create your own story.")